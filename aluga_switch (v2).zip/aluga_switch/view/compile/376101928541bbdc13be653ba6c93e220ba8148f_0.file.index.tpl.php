<?php
/* Smarty version 3.1.45, created on 2022-06-01 01:39:28
  from 'C:\new xamp\htdocs\aula_web\aluga_switch\view\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.45',
  'unifunc' => 'content_6296a730b96116_48502316',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '376101928541bbdc13be653ba6c93e220ba8148f' => 
    array (
      0 => 'C:\\new xamp\\htdocs\\aula_web\\aluga_switch\\view\\index.tpl',
      1 => 1654037386,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6296a730b96116_48502316 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="Vinicius Marcondes/Victor Araujo" content="">
    <title>Home | Aluga Switch</title>
    <link href="view/tema/css/bootstrap.min.css" rel="stylesheet">
    <link href="view/tema/css/font-awesome.min.css" rel="stylesheet">
    <link href="view/tema/css/prettyPhoto.css" rel="stylesheet">
    <link href="view/tema/css/price-range.css" rel="stylesheet">
    <link href="view/tema/css/animate.css" rel="stylesheet">
	<link href="view/tema/css/main.css" rel="stylesheet">
	<link href="view/tema/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <?php echo '<script'; ?>
 src="js/html5shiv.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="js/respond.min.js"><?php echo '</script'; ?>
>
    <![endif]-->       
    <link rel="shortcut icon" href="view/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +11 940436208</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> alugaswitchloja@gmail.com</a></li>
								
							</ul>
						</div>
					</div>


					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img width="100px" src="view/images/logo.JPG" alt="" /></a>
						</div>
						
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li class="menu" ><a href="verificar.php" class="menu"><i class="fa fa-user"></i> Minha Conta</a></li>
								<li class="menu"><a href="Sair.php" class="menu"><i class="fa fa-crosshairs"></i> Sair</a></li>
								<li class="menu"><a href="carrinho.php" class="menu"><i class="fa fa-shopping-cart"></i> Carrinho</a></li>
								<li class="menu"><a href="login.php" class="menu"><i class="fa fa-lock"></i> Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="index.php" class="active">Home</a></li>
								<li><a href="contato.php">Contato</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="search_box pull-right">
							<input id ='pesquisa' type="text" placeholder="O que está procurando?"/>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->

	
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Categoria</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Corrida</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Família</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Infantil</a></h4>
								</div>
							</div>
							
						</div><!--/category-products-->
											
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Jogos Disponíveis</h2>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="view/images/Pokemon.webp" alt="" />
											<h2>R$ 5,00</h2>
											<p>Pokémon Arceus</p>
											<a href="produtos.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Ver produto</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>R$ 5,00</h2>
												<p>Pokémon Arceus</p>
												<a href="produtos.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Ver produto</a>
											</div>
										</div>
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<img src="view/images/animalcrossing.jpg" alt="" />
										<h2>R$ 5,00</h2>
										<p>Animal Crossing</p>
										<a href="produtos.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Ver produto</a>
									</div>
									<div class="product-overlay">
										<div class="overlay-content">
											<h2>R$ 5,00</h2>
											<p>Animal Crossing</p>
											<a href="produtos.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Ver produto</a>
										</div>
									</div>
								</div>
								
							</div>
						
						
					</div><!--features_items-->
									
				</div>
			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span style="color: red;">Aluga</span> 

							<span style="color: black;"> Switch</span></h2>
							<p>Loja de aluguel de games de Nintendo Switch</p>
						</div>
					</div>
					<div class="col-sm-7">
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="view/images/jogolaranja.jpg" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="view/images/igns-top-25-nintendo-switch-games_92t4.jpg" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="view/images/cuphead-gameplay-home.webp" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
							
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="view/images/nintendo-switch-700x467.jpg" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
							
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="view/images/home/map.png" alt="" />
							<p>São Paulo,</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">2022 Aluga Switch</p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	
    <?php echo '<script'; ?>
 src="js/jquery.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="js/bootstrap.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="js/jquery.scrollUp.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="js/price-range.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="js/jquery.prettyPhoto.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="js/main.js"><?php echo '</script'; ?>
>
</body>
</html><?php }
}

<?php
/* Smarty version 3.1.45, created on 2022-05-20 02:37:58
  from 'C:\xampp\htdocs\aula_web\aluga_switch\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.45',
  'unifunc' => 'content_6286e2e682c583_13764453',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2cab17176914d3e3dc9efb0b8402c06980a3f6e8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\aula_web\\aluga_switch\\index.tpl',
      1 => 1653007074,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6286e2e682c583_13764453 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    Página com o Smarty

    <h1><?php echo $_smarty_tpl->tpl_vars['NOME']->value;?>
 </h1>
</body>
</html><?php }
}

<?php
require_once 'conecta_banco.php';


	$nome = $_POST["nome"];
	$senha = $_POST["senha"];

	//monta sql para o banco de dados ,
	$sql = "INSERT  INTO usuarios (nome, senha) VALUES ('" . $nome . "','" . $senha . "')";


	$stmt = $conn->prepare($sql);
	$stmt->execute();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login | Aluga Switch</title>
    <link href="view/tema/css/bootstrap.min.css" rel="stylesheet">
    <link href="view/tema/css/font-awesome.min.css" rel="stylesheet">
    <link href="view/tema/css/prettyPhoto.css" rel="stylesheet">
    <link href="view/tema/css/price-range.css" rel="stylesheet">
    <link href="view/tema/css/animate.css" rel="stylesheet">
	<link href="view/tema/css/main.css" rel="stylesheet">
	<link href="view/tema/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
<?php
    /*session_start();
    if (empty($_SESSION)){
        $erro = "<br>ERRO: Para acessar fazer o LOGIN!<br>";
        $chamada = "Location: login2.php?mensagemErro=".
        $erro;
        header($chamada);
    }*/
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="style.css">   
    <title>Document</title>
</head>
<body>
    
    <?php

        session_start();
       
    ?>
    </head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +11 940436208</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> alugaswitchloja@gmail.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href=""><i class="fa fa-facebook"></i></a></li>
								<li><a href=""><i class="fa fa-twitter"></i></a></li>
								<li><a href=""><i class="fa fa-linkedin"></i></a></li>
								<li><a href=""><i class="fa fa-dribbble"></i></a></li>
								<li><a href=""><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.html"><img width="100px" src="view/images/logo.JPG" alt="" /></a>
						</div>
						
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li class="menu" ><a href="#" class="menu"><i class="fa fa-user"></i> Minha Conta</a></li>
								<li class="menu"><a href="Sair.php" class="menu"><i class="fa fa-crosshairs"></i> Sair</a></li>
								<li class="menu"><a href="carrinho.php" class="menu"><i class="fa fa-shopping-cart"></i> Carrinho</a></li>
								<li class="menu"><a href="login.php" class="menu"><i class="fa fa-lock"></i> Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="index.php" class="active">Home</a></li>
								<li><a href="contato.php">Contato</a></li>
							</ul>
						</div>
					</div>
					
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
   
	<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Cadastro realizado!</h2>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
										  Muito bem, já pode fazer o seu <a href="login.php">login</a>
										</div>
										
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
                
									</div>
									
								</div>
								
							</div>
						
						
					</div><!--features_items-->
				</div>
   
</body>
</html>
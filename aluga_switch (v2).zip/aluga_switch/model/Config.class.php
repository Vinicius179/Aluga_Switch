<?php

Class Config{

    #Informações básicas do site
    const SITE_URL = "http://localhost";
    const SITE_PASTA = "aluga_switch";
    const SITE_NOME = "Aluga Switch";
    const SITE_EMAIL_ADM = "alugaswitchloja@gmail.com";

    #informações do banco de dados
    const BD_HOST = "localhost",
          BD_USER = "root", 
          BD_SENHA = "",
          BD_BANCO = "aluga_switch_bd";

    #Informações para php Mailler
     const EMAIL_HOST = "smtp.gmail.com";
     const EMAIL_USER = "alugaswitchloja@gmail.com";
     const EMAIL_NOME = "alugaswitchloja@gmail.com";
     const EMAIL_SENHA = "Switch3434";
     const EMAIL_PORTA = 587; 
     const EMAIL_SMTPAUTH = "true";
     const EMAIL_SMTPSECURE = "tls";
     const EMAIL_COPIA = "alugaswitchloja@gmail.com";

}
?>

<?php

session_start();
if($_SESSION){
    echo "Olá ".$_SESSION['usuario'];
}
require './lib/autoload.php';






#$email = new PHPMailer();
$smarty = new Template();
Rotas::get_pagina();


#valores para o template
$smarty->assign('NOME', 'VINICIUS');
$smarty->assign('GET_TEMA', Rotas::get_SiteTEMA());

$smarty->display('index.tpl');


?>


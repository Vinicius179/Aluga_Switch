

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="Vinicius Marcondes/Victor Araujo" content="">
    <title>Home | Aluga Switch</title>
    <link href="view/tema/css/bootstrap.min.css" rel="stylesheet">
    <link href="view/tema/css/font-awesome.min.css" rel="stylesheet">
    <link href="view/tema/css/prettyPhoto.css" rel="stylesheet">
    <link href="view/tema/css/price-range.css" rel="stylesheet">
    <link href="view/tema/css/animate.css" rel="stylesheet">
	<link href="view/tema/css/main.css" rel="stylesheet">
	<link href="view/tema/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +11 940436208</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> alugaswitchloja@gmail.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img width="100px" src="view/images/logo.JPG" alt="" /></a>
						</div>
						
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li class="menu" ><a href="verificar.php" class="menu"><i class="fa fa-user"></i> Minha Conta</a></li>
								<li class="menu"><a href="Sair.php" class="menu"><i class="fa fa-crosshairs"></i> Sair</a></li>
								
								<li class="menu"><a href="carrinho.php" class="menu"><i class="fa fa-shopping-cart">
								</i> Carrinho</a></li>
								<li class="menu"><a href="login.php" class="menu"><i class="fa fa-lock"></i> Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="index.php" class="active">Home</a></li>
								<li><a href="contact-us.html">Contato</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="search_box pull-right">
							<input id ='pesquisa' type="text" placeholder="O que está procurando?"/>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	
	
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						
											
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img src="view/images/animal_crossing_capa.jpg" alt="" />
								
							</div>
							<div id="similar-product" class="carousel slide" data-ride="carousel">
								
								  <!-- Wrapper for slides -->
								    <div class="carousel-inner">
										<div class="item active">
										  <a href=""><img src="view/images/animal_crossing01.webp" alt=""></a>
										  <a href=""><img src="view/images/animal_crossing02.jpg" alt=""></a>
										  
										</div>
										
										
									</div>

								  <!-- Controls -->
								  <a class="left item-control" href="#similar-product" data-slide="prev">
									<i class="fa fa-angle-left"></i>
								  </a>
								  <a class="right item-control" href="#similar-product" data-slide="next">
									<i class="fa fa-angle-right"></i>
								  </a>
							</div>

						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
								<img src="view/images/product-details/new.jpg" class="newarrival" alt="" />
								<h2>Animal Crossing</h2>
								<p>Web ID: 1089772</p>
								<img src="view/images/product-details/rating.png" alt="" />
								<span>
									<span>R$ 5,00</span>
									<label>Quantidade de dias:</label>
									<input type="text" value="3" />
									<button type="button" class="btn btn-fefault cart">
										<i class="fa fa-shopping-cart"></i>
										<a class = 'link_carrinho' href="carrinho.php"> Realizar Pedido!</a>
									</button>
								</span>
								<p><b>Disponibilidade:</b> Em estoque</p>
								<p><b>Marca:</b> Nintendo</p>
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->


									
				</div>
			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span style="color: red;">Aluga</span> 

							<span style="color: black;"> Switch</span></h2>
							<p>Loja de aluguel de games de Nintendo Switch</p>
						</div>
					</div>
					<div class="col-sm-7">
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="view/images/jogolaranja.jpg" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="view/images/igns-top-25-nintendo-switch-games_92t4.jpg" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="view/images/cuphead-gameplay-home.webp" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
							
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="view/images/nintendo-switch-700x467.jpg" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
							
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="view/images/home/map.png" alt="" />
							<p>São Paulo,</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">2022 Aluga Switch</p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	
    <script src="tema/js/jquery.js"></script>
	<script src="tema/js/bootstrap.min.js"></script>
	<script src="tema/js/jquery.scrollUp.min.js"></script>
	<script src="tema/js/price-range.js"></script>
    <script src="tema/js/jquery.prettyPhoto.js"></script>
    <script src="tema/js/main.js"></script>
</body>
</html>
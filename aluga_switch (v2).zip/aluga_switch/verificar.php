<?php
  require_once 'conecta_banco.php';
  // executa SELECT
  $stmt = $conn->prepare("SELECT nome, senha FROM usuarios");
  $stmt->execute();
  $recordSet = $stmt->fetchAll();
  $user = $_POST["login"];
  $senhal = $_POST["senhal"];
  $erro = "";
  // listar os dados 
echo 'Usuário ou senha incorretos';
  if(empty($senhal and $senhal)){
    $erro =  "<br> Favor preencher todos os campos"; 
}else{
  foreach($recordSet as $k=>$v) {
        if(!($v['nome']== $user and $v['senha'] == $senhal)){
            echo  "";
        }else{
            if ($erro == "") {
                session_start();
                $_SESSION['usuario']=$user;
                    header('Location: Visitante.php');
            }
            else
            {
            $chamada = "Location: login.php?mensagemErro=".$erro;
            session_destroy();
            header($chamada);
            }
        }
  }
}
   /*require_once 'conecta_banco.php';

   print_r($_POST);
   
   
    if(empty($senhal and $senhal)){
        $erro =  "<br> Favor preencher todos os campos"; 
        
    }
   
    else{
        if(!($user == $nome and $senhal == $senha ))
        {
            $erro = "<br> Usuário ou senha invalidos"; 
        }
        else{
            $erro ="<br> / invalidos";
        }
    }
    if ($erro == "") {
        session_start();
        $_SESSION['usuario']=$user;
            header('Location: Visitante.php');
    }
    else
    {
    $chamada = "Location: login.php?mensagemErro=".$erro;
    session_destroy();
    header($chamada);
    }
       
    $stmt = $conn->prepare($sql);
	$stmt->execute();
    */
 ?>
